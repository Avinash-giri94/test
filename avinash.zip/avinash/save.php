<?php
	 
	$conn = mysqli_connect("localhost", "root", "root", "testing");
 
if (mysqli_connect_errno()) {
    echo "Failed to connect to MySQL: " . mysqli_connect_error();
    exit();
}
	$name=$_POST['name'];
	// $email=$_POST['email'];
	// $phone=$_POST['phone'];
	// $city=$_POST['city'];
	$sql = "INSERT INTO crud(name) 
	VALUES ('$name')";
	if (mysqli_query($conn, $sql)) {
		echo json_encode(array("statusCode"=>200));
	}
	else {
		echo json_encode(array("statusCode"=>201));
	}
	mysqli_close($conn);

}
$query = "SELECT * FROM user";
$data = mysqli_query($conn,$query);
 $Total = mysqli_num_rows($data);
 $result = mysqli_fetch_assoc($data);
 echo $result[name];
 


?>
 